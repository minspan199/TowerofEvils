//package com.michael.pan.eviltower.views;
//
//class MainThreadTexture {
//
//	public MainThreadTexture(GameTextureView gameTextureView) {
//
//	}
//}
