<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="terrains" tilewidth="32" tileheight="32" tilecount="45" columns="1">
 <image source="../res/drawable/terrains.png" width="32" height="1440"/>
 <terraintypes>
  <terrain name="wallStone" tile="12"/>
  <terrain name="grass" tile="1"/>
  <terrain name="floorGround" tile="8"/>
  <terrain name="New Terrain" tile="24"/>
  <terrain name="New Terrain" tile="23"/>
  <terrain name="New Terrain" tile="22"/>
  <terrain name="New Terrain" tile="27"/>
  <terrain name="New Terrain" tile="26"/>
  <terrain name="New Terrain" tile="25"/>
  <terrain name="New Terrain" tile="28"/>
  <terrain name="New Terrain" tile="30"/>
  <terrain name="New Terrain" tile="0"/>
 </terraintypes>
 <tile id="0" terrain=",,,10"/>
 <tile id="8" terrain="0,0,0,0"/>
 <tile id="9" terrain=",0,,"/>
 <tile id="22" terrain=",,,4"/>
 <tile id="23" terrain="3,3,3,3"/>
 <tile id="25" terrain=",7,,"/>
 <tile id="26" terrain=",6,,"/>
 <tile id="27" terrain="5,,,"/>
 <tile id="28" terrain=",,8,"/>
 <tile id="30" terrain=",,9,"/>
</tileset>
